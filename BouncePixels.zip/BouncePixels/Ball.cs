﻿using System;
namespace BouncePixels
{
	public class Ball
	{
		public int X;
		public int Y;
		public int Direction_Y;
		public int Direction_X;
		public int Evolution;
		public ConsoleColor Color;

		private Random random;

		public Ball(int x,int y)
		{
			X = x;
			Y = y;
			Direction_Y = 0;
			Direction_X = 0;
			Color = ConsoleColor.White;
			Evolution = 0;
			random = new Random();
		}

		public void RandomDirecion()
		{
			int x_r = 0;
			int y_r = 0;

			while ((x_r == 0) || (y_r == 0) )
			{
				x_r = random.Next(-2, 2);
				y_r = random.Next(-2, 2);
			}

			Direction_Y = y_r;
			Direction_X = x_r;
		}
	}
}
