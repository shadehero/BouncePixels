﻿using System;
using System.Collections.Generic;

namespace BouncePixels
{
	public class Box
	{
		public int X;
		public int Y;
		public int Width;
		public int Height;
		public List<Ball> Balls;
		private Random rand;

		public Box(int x,int y,int width,int height)
		{
			X = x;
			Y = y;
			Width = width;
			Height = height;
			Balls = new List<Ball>();
			rand = new Random();
		}

		private void DrawBall(int x, int y, ConsoleColor color)
		{
			Console.SetCursorPosition(x, y);
			Console.ForegroundColor = color;
			Console.Write("█");
			Console.ResetColor();
		}

		public void DrawBalls()
		{
			foreach (Ball b in Balls.ToArray())
			{
				// Moving
				b.X += b.Direction_X;
				b.Y += b.Direction_Y;

				// Evolution
				for (int i = 0; i < Balls.Count; i++)
				{
					if ((b.X == Balls[i].X) && (b.Y == Balls[i].Y))
					{
						if (!b.Equals(Balls[i]))
						{
							if (b.Evolution == Balls[i].Evolution)
							{
								b.Evolution++;
								Balls.RemoveAt(i);
							}
						}

					}
				}

				// Bouncing
				if (b.X == X + 1) { b.Direction_X  = 1;	}
				if (b.X == Width + 1) { b.Direction_X = -1;	}
				if (b.Y == Y) { b.Direction_Y = 1; }
				if (b.Y == Height){ b.Direction_Y = -1; }

				// Drawing
				switch (b.Evolution)
				{
					case 0:
						DrawBall(b.X, b.Y, ConsoleColor.White);
						break;
					case 1:
						DrawBall(b.X, b.Y, ConsoleColor.Cyan);
						break;
					case 2:
						DrawBall(b.X, b.Y, ConsoleColor.Green);
						break;
					case 3:
						DrawBall(b.X, b.Y, ConsoleColor.Yellow);
						break;
					case 5:
						DrawBall(b.X, b.Y, ConsoleColor.Red);
						break;
				}


			}
		}

		public void DrawBorder()
		{
			// Top
			for (int i = 0; i < Width; i++)
			{
				Console.SetCursorPosition(X + i, Y -1);
				Console.Write("█");
			}
			Console.SetCursorPosition(X + Width, Y - 1);
			Console.Write("█");

			// Bot
			for (int i = 0; i < Width; i++)
			{
				Console.SetCursorPosition(X + i, Y + Height);
				Console.Write("█");
			}

			// Left
			for (int i = 0; i < Height; i++)
			{
				Console.SetCursorPosition(X, Y + i);
				Console.Write("█");
			}

			// Right
			for (int i = 0; i < Height; i++)
			{
				Console.SetCursorPosition(X + Width, Y + i);
				Console.Write("█");
			}
			Console.SetCursorPosition(X + Width, Y + Height);
			Console.Write("█");

		}
	}
}
