﻿using System;
using System.Threading;

namespace BouncePixels
{
	class MainClass
	{
		static Box box = new Box(2, 1, 50, 22);
		static Thread InputThread;

		public static void Main(string[] args)
		{
			Console.Title = "BouncePixels By ShadeHero";
			InputThread = new Thread(Input);
			InputThread.IsBackground = true;
			InputThread.Start();

			while (true)
			{
				Console.Clear();

				// Box
				box.DrawBorder();
				box.DrawBalls();

				// Stats
				Console.SetCursorPosition(box.X + box.Width + 3, box.Y);
				Console.WriteLine("Ball Count: {0}", box.Balls.Count);

				int b_White = 0;
				int b_Cyan = 0;
				int b_Green = 0;
				int b_Yellow = 0;
				int b_Red = 0;

				for (int i = 0; i < box.Balls.Count; i++)
				{
					if (box.Balls[i].Evolution == 0) { b_White++; }
					if (box.Balls[i].Evolution == 1) { b_Cyan++; }
					if (box.Balls[i].Evolution == 2) { b_Green++; }
					if (box.Balls[i].Evolution == 3) { b_Yellow++; }
					if (box.Balls[i].Evolution == 4) { b_Red++;}
				}

				Console.SetCursorPosition(box.X + box.Width + 3, box.Y + 2);
				Console.ForegroundColor = ConsoleColor.White;
				Console.Write("█");
				Console.ResetColor();
				Console.Write(" : {0}", b_White);

				Console.SetCursorPosition(box.X + box.Width + 3, box.Y + 4);
				Console.ForegroundColor = ConsoleColor.Cyan;
				Console.Write("█");
				Console.ResetColor();
				Console.Write(" : {0}", b_Cyan);

				Console.SetCursorPosition(box.X + box.Width + 3, box.Y + 6);
				Console.ForegroundColor = ConsoleColor.Green;
				Console.Write("█");
				Console.ResetColor();
				Console.Write(" : {0}", b_Green);

				Console.SetCursorPosition(box.X + box.Width + 3, box.Y + 8);
				Console.ForegroundColor = ConsoleColor.Yellow;
				Console.Write("█");
				Console.ResetColor();
				Console.Write(" : {0}", b_Yellow);

				Console.SetCursorPosition(box.X + box.Width + 3, box.Y + 10);
				Console.ForegroundColor = ConsoleColor.Red;
				Console.Write("█");
				Console.ResetColor();
				Console.Write(" : {0}", b_Red);
				Console.ResetColor();
				Thread.Sleep(250);
			}
		}

		static void Input()
		{
			while (true)
			{
				Ball b = new Ball(box.Width / 2, box.Height / 2);
				b.RandomDirecion();

				if (box.Balls.Count < 100)
				{
					box.Balls.Add(b);
				}
				Thread.Sleep(100);
			}
		}
	}
}
